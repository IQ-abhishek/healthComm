﻿namespace healthcomm.Models
{
    public record RoomDetail(
        string Id,
        string Name,
        int ParticipantCount,
        int MaxParticipants);
}