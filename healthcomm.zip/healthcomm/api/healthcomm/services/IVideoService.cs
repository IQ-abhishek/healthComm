﻿using System.Collections.Generic;
using System.Threading.Tasks;
using healthcomm.Models;


namespace healthcomm.services
{
    public interface IVideoService
    {
        string GetTwilioJwt(string identity);
        Task<IEnumerable<RoomDetail>> GetAllRoomsAsync();
    }
}
