﻿namespace healthcomm.options
{
    public class TwilioSetting
    {
    
            public string AccountSid { get; set; }

            public string ApiKey { get; set; }
            public string ApiSecret { get; set; }
        }
    
}


